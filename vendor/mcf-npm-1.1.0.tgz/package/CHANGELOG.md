# Changelog

## 1.1.0

- Added exact manifest-first dispatch for MCF 1.0 and MCF 1.1.
- Added all MCF 1.1 package kinds, questions, activities, metadata, assets,
  extensions, safe ZIP reading, and closed package-set resolution.
- Added structured diagnostics, inspect/capabilities commands, JSON output,
  expected-version checks, documented exit codes, and remote policy opt-in.
- Preserved directory and standalone HTML compilation and corrected asset/content
  fidelity in both modes.
- Added direct canonical conformance tests and explicit static-reader fallbacks.
- Expanded public discriminated models and package APIs.
