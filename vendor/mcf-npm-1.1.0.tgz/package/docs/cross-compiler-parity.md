# Cross-compiler parity

| Responsibility        | TypeScript                         | Python                        |
| --------------------- | ---------------------------------- | ----------------------------- |
| Version dispatch      | `src/package.ts`                   | `src/mcf_compiler/package.py` |
| Package reader        | `src/package-reader.ts`            | `package_reader.py`           |
| 1.0 parser            | `src/parser.ts`                    | `parser.py`                   |
| 1.1 parser/validation | `src/parser11.ts`                  | `parser11.py`                 |
| Normalized model      | `src/model.ts`                     | `model.py`                    |
| Compiler/embedding    | `src/compiler.ts`                  | `compiler.py`                 |
| HTML controls         | `src/render.ts`                    | `render.py`                   |
| Browser behavior      | `src/reader/**`                    | generated `assets/reader/**`  |
| Scoring/completion    | `reader/questions.ts`, `player.ts` | same generated JS             |

`npm run sync:python-reader` builds and copies the canonical browser assets.
Python's `test_reader_sync.py` rejects drift. Model/diagnostic parity is tested
from Python against the Node distribution; learner parity is tested in the
shared browser matrix.
