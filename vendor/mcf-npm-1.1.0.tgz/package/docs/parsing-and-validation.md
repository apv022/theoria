# Parsing and validation

`validatePackage` opens the package transport, reads only the root manifest, and
dispatches the exact declared version. `1.0` goes to `parseCourse10`; `1.1`
goes to `parsePackage11`; every other exact string produces
`MCF_VERSION_UNSUPPORTED`. Archive transport never changes this choice.

The 1.1 YAML loader rejects duplicate keys, aliases, anchors, tags, merge keys,
non-string keys, non-finite numbers, BOMs, and excessive structures before
schema/semantic processing. Schema errors describe shape. Parser and semantic
diagnostics cover identity, paths, references, answers, rubrics, completion,
assets, extensions, and package sets. Rendering policy is deliberately not
source validity.

Tests: `test/conformance.test.ts`, `test/validation.test.ts`, and
`test/parser.test.ts`.
