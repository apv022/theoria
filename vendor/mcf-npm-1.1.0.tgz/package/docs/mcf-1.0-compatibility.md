# MCF 1.0 compatibility

Root manifests declaring exactly `1.0` use only `parser.ts` and the 1.0
contract. No 1.1 defaults or required fields are applied, and emitted data keeps
`mcf: "1.0"`. Directory and safely extracted archive transports are supported.
MCF 1.0 essay work remains manual; the static reader does not invent a grade.
