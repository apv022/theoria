# MCF 1.1 support

The parser supports all five package kinds and all nine question types.
Course, module, and lesson packages compile; banks and asset collections
validate/inspect/resolve but intentionally do not emit learner HTML. Restricted
YAML, dependencies, question references, metadata, assets, rubrics, completion,
and extensions are retained. Capability conformance remains empty until every
mandatory class behavior is independently demonstrated.
