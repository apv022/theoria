# API and CLI migration for mcf-npm 1.1.0

The implementation release adds MCF 1.1 without converting MCF 1.0 source.

## Compatible behavior

- `parseCourse`, `compile`, and `compileSingleFile` remain available.
- `mcf validate`, `mcf compile --output`, and `mcf compile --single-file` remain.
- Existing MCF 1.0 normalized course/activity/question fields remain present.

## Type changes

- `Course.mcf` is now `"1.0" | "1.1"` and `Course.kind` is `"course"`.
- Activity and question types include their 1.1 values.
- Numeric tolerance is a number or `{ absolute, relative }`.
- Diagnostics now require portable `code` and `severity`; optional source
  location and `object_id` are exposed.
- `parsePackage` returns a discriminated union for course, module, lesson,
  question-bank, and asset-collection packages.

Code that assumed `Course.mcf` was always the literal `"1.0"` or exhaustively
switched over the old six question types must be updated.

## New APIs

- `validatePackage(input, options)`
- `parsePackage(input, options)`
- `parsePackageSet({ packages, ...options })`
- `capabilities(implementationVersion?)`
- `parseCourse(input, options)`
- optional `ParseOptions` on both compilation functions

## CLI changes

Validation and compilation now detect the manifest version. Add
`--expected-version 1.0|1.1` when a pipeline requires one exact source format.
Use `--format json` for machine-readable diagnostics, `inspect` for package
metadata, `capabilities` for feature negotiation, and repeatable `--package`
arguments for closed-set resolution.

Do not derive MCF source version from the npm implementation version.
