# Known limitations

- Static output cannot deliver files to an instructor or finalize manual grades.
- Remote content is not fetched; YouTube playback requires network access and
  may require HTTP rather than `file://`.
- Archive parse APIs retain temporary extracted roots until process exit because
  returned normalized models may still need asset bytes.
- Source locations are not yet precise for every nested schema field.
- No complete MCF writer exists; writer conformance is not claimed.
- Browser acceptance presently concentrates on the adversarial feature package;
  the full nine-type reload matrix should continue expanding.
