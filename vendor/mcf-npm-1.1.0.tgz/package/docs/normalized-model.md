# Normalized model

`src/model.ts` is the authoritative discriminated model. Every package retains
`mcf`, `kind`, `id`, `version`, metadata, relationships, assets, rubrics, and
extensions. Ordered arrays remain authored arrays. Bank resolution adds
`source_reference` without changing stable question identity.

The compiler's browser data removes filesystem-only `root`, diagnostics, and
source paths, but preserves educational fields including activity content,
completion expressions, scoring data, rubrics, and extensions. `sourceKind`
exists only on the internal compile adapter; emitted `kind` is always the
authored package kind.
