# Repository structure

```text
.github/workflows/ci.yml       CI entry point: build, lint, tests, browser tests
src/cli.ts                     public command-line adapter
src/package.ts                 public version dispatch/package-set API
src/package-reader.ts          secured directory and ZIP transport boundary
src/parser.ts                  exact MCF 1.0 course parser
src/parser11.ts                exact MCF 1.1 package/lesson/semantic parser
src/yaml-profile.ts            restricted MCF 1.1 YAML loader
src/model.ts                   shared normalized TypeScript model
src/references.ts              Markdown/media reference discovery
src/render.ts                  sanitized HTML and learner controls
src/compiler.ts                tree and one-file compiler APIs
src/reader/                    canonical editable browser runtime source
dist/                          generated TypeScript and browser build; never edit
scripts/build-reader.mjs       bundles the canonical runtime
scripts/sync-python-reader.mjs copies generated runtime into mcf-python
test/                          unit, integration, conformance, and parity tests
browser/                       Playwright learner-interaction tests
docs/                          maintainer and user documentation
examples/                      compiler-local source fixtures
```

The Python correspondence is documented in `cross-compiler-parity.md`. Schemas
are read from the adjacent read-only `mcf-spec` checkout; unlike Python, Node
does not vendor them. Only `src/reader/**` is editable browser source.
