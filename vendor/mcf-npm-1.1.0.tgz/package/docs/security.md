# Security

Trust boundaries are YAML parsing, archive opening, path resolution, rich HTML,
remote resources, extensions, imported state, and output paths. The compiler
does not execute authored scripts/extensions or fetch remote resources by
default. Markdown HTML is allow-list sanitized; event handlers, scripts,
`javascript:`, `data:text/html`, and `file:` are removed. SVG files are copied,
not injected as active inline markup.

State import checks package identity, schema, maps, arrays, primitive types, and
finite scores before replacement. Output uses staging/rename and rejects source
overlap. See security and validation tests for adversarial cases.
