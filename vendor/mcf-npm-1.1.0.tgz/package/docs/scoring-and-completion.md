# Scoring and completion

Pure functions in `src/reader/questions.ts` implement weighted choice, exact and
partial select, numeric tolerance, Unicode-aware short answer, matching, and
ordering. Zero-point and ungraded questions do not enter a denominator. Manual
required work yields a labeled provisional automatic score, never correctness.

State distinguishes answered, attempted, checked, submitted, passed, and manual
completion. `player.ts` evaluates nested `all`/`any` expressions to depth eight;
`minimum_score` applies only to a true `passed` state. Without an authored
expression, reader policy is: notes need explicit completion; automatic
practice needs required answers checked; manual practice needs submissions;
completion practice needs its conditions; ungraded practice needs responses or
manual completion; assessments with a threshold must pass; assignments need a
valid local submission.
