# Conformance status

The implementation supports MCF 1.0 and 1.1 source contracts, but its capability
document deliberately does not claim a complete `validator`, `reader`,
`writer`, or `package-reader` class.

## Executed canonical coverage

- Every package in `mcf-spec/conformance/suite.yaml` under `valid` passes.
- Every package under `invalid` fails with its required principal diagnostic.
- Canonical restricted-YAML, question-matrix, and activity-matrix cases execute
  directly from the adjacent specification repository.
- Both canonical 1.0 compatibility packages pass under 1.0 rules.
- Directory and standalone compilation tests cover canonical 1.0 and 1.1
  minimal courses without source mutation.

## Implemented 1.1 surfaces

Version-first dispatch; structured diagnostics; five package kinds; safe
directory and ZIP package loading with canonical limits; restricted YAML;
deterministic activity parsing; all nine question shapes; scoring metadata;
rubrics; completion references; assets and integrity; BCP 47; extensions;
closed package sets; question-bank references; CLI inspection; and truthful
capability reporting.

## Remaining conformance gaps

- Validation is separated into YAML/shape and semantic phases in code, but it is
  not an exhaustive JSON Schema 2020-12 evaluator. Some unknown-field and less
  common metadata-shape failures can therefore be diagnosed semantically rather
  than with complete schema parity.
- The complete diagnostic trigger catalog, relationship/asset/capability
  data-case files, extension writer round-trip, and all parser-limit probes are
  not yet automated by this repository.
- Archive local-header/central-directory name equality and encrypted-entry
  handling rely partly on `yauzl`; adversarial coverage is canonical-fixture
  based rather than a separately exhaustive ZIP test matrix.
- Remote fetching is never performed, even with `--allow-remote`; the option
  records explicit policy intent for future resolvers.
- There is no writer/editing API, so optional extensions are preserved in
  normalized models but writer round-trip conformance is not claimed.
- The static reader exposes all core content and explicit fallbacks, but manual
  review, file/URL submission, remote dependency acquisition, rubric grading,
  and provider runtimes are not implemented.
- Lesson completion expressions are validated and retained but the browser
  runtime still uses its existing activity-completion model rather than
  evaluating every authored expression.

These omissions are why `mcf capabilities` reports concrete features with an
empty `conformance` list.
