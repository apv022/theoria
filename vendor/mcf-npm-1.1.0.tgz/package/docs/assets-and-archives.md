# Assets and archives

Package paths are forward-slash relative paths without empty, dot, parent,
absolute, drive, backslash, or NUL segments. ZIP processing rejects duplicates,
encryption/special types, traversal, oversized expansion, excess entries, and
ratios over 200:1. Limits are 4,096 entries, 64 MiB each, and 512 MiB total.

Tree output copies binary assets byte-for-byte. One-file output embeds local
images, audio, video, and fonts with detected MIME types. Compiler-created data
URLs are permitted only on passive media tags; authored active data URLs remain
blocked.
