# Testing

Run `npm ci`, `npm run format:check`, `npm run lint`, `npx tsc --noEmit`,
`npm test`, and `npm run test:browser`. `npm test` covers units, parsers,
validation, canonical conformance, compilation, and normalized parity.
Playwright performs real learner interactions.

The shared four-way suite is run from
`../examplecourses/browser-tests` with `npm test`; it targets Node/Python tree
and one-file outputs with one data-driven scenario. Compilation-success tests
prove only that files were written. They do not prove correct learner behavior.
