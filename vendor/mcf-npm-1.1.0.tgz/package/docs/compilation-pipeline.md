# Compilation pipeline

Both `compile` and `compileSingleFile` call `parseCourse`, which accepts a
course directly or adapts module/lesson structure while retaining `sourceKind`.
The trace is:

```text
CLI/API → openPackageSource → manifest version dispatch → version parser
→ semantic/package-set resolution → normalized model → render
→ atomic tree replacement or atomic standalone write → browser runtime
```

Tree compilation copies source bytes, KaTeX resources, CSS, the generated
runtime, normalized `course.json`, and lesson pages. Standalone compilation
collects referenced local media, encodes it with its MIME type, rewrites KaTeX
fonts, and embeds CSS/runtime/data into one HTML file. Output containment is
checked using canonical future paths before writing.
