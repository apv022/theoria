# mcf-npm

`mcf-npm` validates Modular Curriculum Format (MCF) 1.0 and 1.1 packages and
compiles course packages into an offline static reader. MCF source version and
the npm package version are independent: `mcf-npm@1.1.0` is an implementation
release, not an alias for the MCF 1.1 source contract.

The implementation dispatches from `manifest.yaml` before version-specific
validation. MCF 1.0 source is interpreted only under the 1.0 contract; it is
never relabelled or migrated. MCF 1.1 supports directory and `.mcf.zip`
packages, all five package kinds, all nine question types, extensions,
structured diagnostics, and closed package sets.

## Requirements and commands

Node.js 20 or newer is required for authoring and compilation. Generated course
readers do not require Node.

```bash
npm ci
npm run build

# Exact-version validation is selected automatically.
npm run mcf -- validate ./course
npm run mcf -- validate ./package.mcf.zip --format json
npm run mcf -- validate ./course --expected-version 1.1

# Read-only package information.
npm run mcf -- inspect ./course
npm run mcf -- inspect ./course --format json
npm run mcf -- capabilities

# Existing output modes remain supported.
npm run mcf -- compile ./course --output ./courses
npm run mcf -- compile ./course --single-file ./exports/course.html
```

Use repeatable `--package PATH` inputs on `validate`, `inspect`, or `compile` to
resolve required relationships and question-bank references as a closed set.
Remote fetching is disabled by default. `--allow-remote` is an explicit policy
opt-in; validation itself does not need to fetch remote content.

Exit status is `2` for invalid source, `3` for unsupported or mismatched source
versions, `4` for unsupported required extensions, `5` for security-policy
rejection, and `1` for operational failure.

## API

```ts
import {
  capabilities,
  compile,
  compileSingleFile,
  parseCourse,
  parsePackage,
  parsePackageSet,
  validatePackage,
} from 'mcf-npm';

const result = await validatePackage('./package', { expectedVersion: '1.1' });
if (result.valid) console.log(result.version, result.kind);

const packageModel = await parsePackage('./package');
await compile('./course', './courses');
await compileSingleFile('./course', './course.html');
```

`parsePackage` returns a discriminated `McfPackage` union with `mcf` and `kind`.
`parseCourse` is the course-only compatibility convenience. Validation failures
throw `ValidationError` from parsing/compilation APIs; each diagnostic contains
`code`, `severity`, `message`, `file`, and optional location/object information.
`validatePackage` returns diagnostics without throwing for source-invalid input.

The package does not expose a source writer or migration API. Its capability
declaration intentionally claims no complete MCF conformance class until every
mandatory class-level behavior is covered.

## Static reader behavior

Directory and `--single-file` output preserve the same lesson/activity order and
learner-facing authored content. Standalone output embeds referenced local
binary assets as data URLs. Raw HTML is sanitized; source scripts and active URI
schemes are not executed.

Automatic question types are interactive. Manual and ungraded responses are
saved without invented correctness. Assignment submission declarations are
rendered, but the static reader clearly states that it cannot upload files or
URLs. Remote media requires network access at viewing time.

The reader’s progress store is local implementation state, not MCF source.

## Development

```bash
npm run format:check
npm run lint
npx tsc --noEmit
npm test
npm run compile:examples
npm run test:browser
npm pack --dry-run
```

Canonical conformance tests reference the adjacent `mcf-spec` checkout rather
than copying its corpus. Set up the repositories as siblings:

```text
parent/
├── mcf-npm/
└── mcf-spec/
```

See [architecture](docs/architecture.md), [authoring](docs/authoring.md),
[API and CLI migration](docs/migration-1.1.md), and
[conformance status](docs/conformance.md).
